import { useState, useEffect } from 'react'
import { 
  DollarSign, 
  TrendingUp, 
  Zap, 
  Users, 
  Gift, 
  Rocket, 
  Shield, 
  Clock,
  BarChart3,
  Wallet,
  Globe,
  Star,
  CheckCircle2,
  ArrowRight,
  Menu,
  X,
  Copy,
  ExternalLink,
  Play,
  Pause,
  RefreshCw,
  ShoppingBag
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'

// Income Simulator Component
function IncomeSimulator() {
  const [isRunning, setIsRunning] = useState(false)
  const [totalEarned, setTotalEarned] = useState(0)
  const [monthlyProjection, setMonthlyProjection] = useState(0)
  const [streams, setStreams] = useState([
    { name: 'Affiliate Marketing', rate: 0.15, active: true, color: 'bg-blue-500' },
    { name: 'Print-on-Demand', rate: 0.08, active: true, color: 'bg-purple-500' },
    { name: 'CPA Offers', rate: 0.12, active: true, color: 'bg-green-500' },
    { name: 'Ad Revenue', rate: 0.05, active: true, color: 'bg-yellow-500' },
  ])

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>
    if (isRunning) {
      interval = setInterval(() => {
        const minuteEarnings = streams.reduce((acc, stream) => {
          return acc + (stream.active ? stream.rate : 0)
        }, 0)
        
        setTotalEarned(prev => prev + minuteEarnings)
        setMonthlyProjection(prev => prev + minuteEarnings * 60 * 24 * 30)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isRunning, streams])

  const toggleStream = (index: number) => {
    setStreams(prev => prev.map((stream, i) => 
      i === index ? { ...stream, active: !stream.active } : stream
    ))
  }

  return (
    <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Wallet className="w-6 h-6 text-green-400" />
          Live Income Simulator
        </CardTitle>
        <CardDescription className="text-slate-400">
          Watch your passive income grow in real-time
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="text-center p-6 bg-slate-800/50 rounded-lg">
            <p className="text-sm text-slate-400 mb-2">Total Earned Today</p>
            <p className="text-4xl font-bold text-green-400">${totalEarned.toFixed(2)}</p>
          </div>
          <div className="text-center p-6 bg-slate-800/50 rounded-lg">
            <p className="text-sm text-slate-400 mb-2">Monthly Projection</p>
            <p className="text-4xl font-bold text-blue-400">${monthlyProjection.toFixed(2)}</p>
          </div>
        </div>

        <div className="flex justify-center gap-4">
          <Button 
            onClick={() => setIsRunning(!isRunning)}
            className={isRunning ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}
          >
            {isRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {isRunning ? 'Pause' : 'Start'} Simulation
          </Button>
          <Button 
            variant="outline" 
            onClick={() => {
              setTotalEarned(0)
              setMonthlyProjection(0)
            }}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Reset
          </Button>
        </div>

        <div className="space-y-3">
          <p className="text-sm font-medium text-slate-300">Income Streams</p>
          {streams.map((stream, index) => (
            <div key={stream.name} className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${stream.color}`} />
                <span className="text-slate-300">{stream.name}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm text-slate-400">${stream.rate}/min</span>
                <Button
                  size="sm"
                  variant={stream.active ? "default" : "outline"}
                  onClick={() => toggleStream(index)}
                  className={stream.active ? 'bg-green-600' : ''}
                >
                  {stream.active ? 'Active' : 'Inactive'}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

// Copy to Clipboard Helper
function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false)
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    toast.success('Copied to clipboard!')
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Button 
      size="sm" 
      variant="outline" 
      onClick={copyToClipboard}
      className="gap-2"
    >
      {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
      {label}
    </Button>
  )
}

// Main App Component
function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('home')

  const navItems = [
    { id: 'home', label: 'Home', icon: Rocket },
    { id: 'methods', label: 'Income Methods', icon: TrendingUp },
    { id: 'opm', label: 'OPM Financing', icon: Users },
    { id: 'tools', label: 'Free Tools', icon: Gift },
    { id: 'calculator', label: 'Income Calculator', icon: BarChart3 },
  ]

  useEffect(() => {
    const handleScroll = () => {
      const sections = navItems.map(item => document.getElementById(item.id))
      const scrollPosition = window.scrollY + 200

      sections.forEach((section, index) => {
        if (section) {
          const sectionTop = section.offsetTop
          const sectionHeight = section.offsetHeight
          
          if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
            setActiveSection(navItems[index].id)
          }
        }
      })
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
      setMobileMenuOpen(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-blue-500 rounded-lg flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
                Wealth Engine
              </span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeSection === item.id
                      ? 'bg-slate-800 text-white'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-slate-800"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-slate-900 border-t border-slate-800">
            <div className="px-4 py-2 space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`w-full px-4 py-3 rounded-lg text-sm font-medium text-left flex items-center gap-3 ${
                    activeSection === item.id
                      ? 'bg-slate-800 text-white'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="mb-6 bg-green-500/10 text-green-400 border-green-500/20">
              <Zap className="w-3 h-3 mr-2" />
              Zero Investment Required
            </Badge>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold mb-6 leading-tight">
              Build{' '}
              <span className="bg-gradient-to-r from-green-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
                Passive Wealth
              </span>{' '}
              24/7
            </h1>
            <p className="text-xl text-slate-400 max-w-3xl mx-auto mb-10">
              Discover the most lucrative online income streams that generate money every minute of every day. 
              No upfront costs. No experience needed. Just proven strategies that work.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-8"
                onClick={() => scrollToSection('methods')}
              >
                Start Building Wealth
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-slate-700 hover:bg-slate-800"
                onClick={() => scrollToSection('calculator')}
              >
                Try Income Calculator
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {[
              { label: 'Income Methods', value: '12+', icon: TrendingUp },
              { label: '$0 Investment', value: '100%', icon: Gift },
              { label: 'Free Tools', value: '50+', icon: Zap },
              { label: 'Setup Time', value: '<1hr', icon: Clock },
            ].map((stat, index) => (
              <Card key={index} className="bg-slate-900 border-slate-800 text-center p-6">
                <stat.icon className="w-8 h-8 mx-auto mb-3 text-green-400" />
                <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-slate-400 text-sm">{stat.label}</p>
              </Card>
            ))}
          </div>

          {/* Income Simulator */}
          <IncomeSimulator />
        </div>
      </section>

      {/* Income Methods Section */}
      <section id="methods" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Proven Income Methods
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              These are the most profitable, zero-investment strategies that generate income around the clock
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Affiliate Marketing */}
            <Card className="bg-slate-900 border-slate-800 hover:border-blue-500/50 transition-all group">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <TrendingUp className="w-6 h-6 text-blue-400" />
                </div>
                <CardTitle className="text-white">Affiliate Marketing</CardTitle>
                <CardDescription className="text-slate-400">
                  Earn 30-50% recurring commissions promoting high-value products
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {[
                    'ClickFunnels: 30% recurring',
                    'HubSpot: 30% recurring',
                    'Moosend: 40% lifetime',
                    'Teachable: 30% recurring'
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                      {item}
                    </div>
                  ))}
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Start Earning
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            {/* Print-on-Demand */}
            <Card className="bg-slate-900 border-slate-800 hover:border-purple-500/50 transition-all group">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Globe className="w-6 h-6 text-purple-400" />
                </div>
                <CardTitle className="text-white">Print-on-Demand</CardTitle>
                <CardDescription className="text-slate-400">
                  Sell custom products without inventory or upfront costs
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {[
                    'Printify: $0 upfront',
                    '1,300+ products available',
                    'No payment until sale',
                    'Auto fulfillment worldwide'
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                      {item}
                    </div>
                  ))}
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">
                  Create Store
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            {/* CPA Marketing */}
            <Card className="bg-slate-900 border-slate-800 hover:border-green-500/50 transition-all group">
              <CardHeader>
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Zap className="w-6 h-6 text-green-400" />
                </div>
                <CardTitle className="text-white">CPA Marketing</CardTitle>
                <CardDescription className="text-slate-400">
                  Get paid for leads, sign-ups, and app installs
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {[
                    '$3-150 per action',
                    'Free traffic methods',
                    'No selling required',
                    'Instant approval networks'
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                      {item}
                    </div>
                  ))}
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">
                  Join Networks
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            {/* Dropshipping */}
            <Card className="bg-slate-900 border-slate-800 hover:border-yellow-500/50 transition-all group">
              <CardHeader>
                <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <ShoppingBag className="w-6 h-6 text-yellow-400" />
                </div>
                <CardTitle className="text-white">Dropshipping</CardTitle>
                <CardDescription className="text-slate-400">
                  Sell products without holding inventory
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {[
                    'AutoDS automation tools',
                    'Free platform trials',
                    'Winning product research',
                    'Supplier handles shipping'
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                      {item}
                    </div>
                  ))}
                </div>
                <Button className="w-full bg-yellow-600 hover:bg-yellow-700">
                  Start Dropshipping
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            {/* Content Creation */}
            <Card className="bg-slate-900 border-slate-800 hover:border-red-500/50 transition-all group">
              <CardHeader>
                <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Star className="w-6 h-6 text-red-400" />
                </div>
                <CardTitle className="text-white">Content & Ads</CardTitle>
                <CardDescription className="text-slate-400">
                  Monetize content with ads and sponsorships
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {[
                    'YouTube ad revenue',
                    'Blog monetization',
                    'Sponsored content',
                    'Adsterra network'
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                      {item}
                    </div>
                  ))}
                </div>
                <Button className="w-full bg-red-600 hover:bg-red-700">
                  Create Content
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            {/* Digital Products */}
            <Card className="bg-slate-900 border-slate-800 hover:border-indigo-500/50 transition-all group">
              <CardHeader>
                <div className="w-12 h-12 bg-indigo-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Wallet className="w-6 h-6 text-indigo-400" />
                </div>
                <CardTitle className="text-white">Digital Products</CardTitle>
                <CardDescription className="text-slate-400">
                  Create once, sell forever with 100% profit margins
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {[
                    'E-books & courses',
                    'Templates & tools',
                    'Stock photos & videos',
                    'Software & apps'
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                      {item}
                    </div>
                  ))}
                </div>
                <Button className="w-full bg-indigo-600 hover:bg-indigo-700">
                  Create Product
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* OPM Section */}
      <section id="opm" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              OPM Financing Strategy
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Use Other People's Money to fund your online empire - no personal investment required
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                    <Users className="w-5 h-5 text-green-400" />
                  </div>
                  <CardTitle className="text-white">Joint Ventures</CardTitle>
                </div>
                <CardDescription className="text-slate-400">
                  Partner with investors who provide capital while you handle execution
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    'Investor funds: $500-$5,000 startup',
                    'You provide: Work & expertise',
                    'Profit split: 50/50 or 60/40',
                    'No personal money risk'
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-slate-800/50 rounded-lg">
                      <CheckCircle2 className="w-5 h-5 text-green-400 mt-0.5" />
                      <span className="text-slate-300">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                    <Rocket className="w-5 h-5 text-blue-400" />
                  </div>
                  <CardTitle className="text-white">Revenue Sharing</CardTitle>
                </div>
                <CardDescription className="text-slate-400">
                  Get upfront funding in exchange for future revenue percentage
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    'Platforms: StarterStory, MicroAcquire',
                    'Funding: $1,000-$50,000 available',
                    'Repayment: % of revenue over time',
                    'Keep full business control'
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-slate-800/50 rounded-lg">
                      <CheckCircle2 className="w-5 h-5 text-green-400 mt-0.5" />
                      <span className="text-slate-300">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                    <Shield className="w-5 h-5 text-purple-400" />
                  </div>
                  <CardTitle className="text-white">Credit Partnerships</CardTitle>
                </div>
                <CardDescription className="text-slate-400">
                  Leverage business credit and lines of credit for 0% financing
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    'Business credit cards: 0% APR 12-18 months',
                    'Lines of credit: $10,000-$100,000',
                    'Equipment financing for tools',
                    'Build business credit score'
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-slate-800/50 rounded-lg">
                      <CheckCircle2 className="w-5 h-5 text-green-400 mt-0.5" />
                      <span className="text-slate-300">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-yellow-400" />
                  </div>
                  <CardTitle className="text-white">Pre-Sales Model</CardTitle>
                </div>
                <CardDescription className="text-slate-400">
                  Sell before you create - validate and fund with customer money
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    'Launch product before creation',
                    'Use sales to fund development',
                    'Zero risk, proven demand',
                    'Kickstarter, Indiegogo platforms'
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-slate-800/50 rounded-lg">
                      <CheckCircle2 className="w-5 h-5 text-green-400 mt-0.5" />
                      <span className="text-slate-300">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Partnership Opportunities */}
          <Card className="mt-8 bg-gradient-to-br from-slate-900 to-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Users className="w-6 h-6 text-green-400" />
                Ready-Made Partnership Opportunities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-white">Investor Partnership Program</h4>
                  <p className="text-slate-400 text-sm">
                    Connect with investors looking to fund proven online business models. 
                    We match you with capital partners.
                  </p>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="bg-green-600 hover:bg-green-700">
                        Find Investor
                        <ExternalLink className="w-4 h-4 ml-2" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-700">
                      <DialogHeader>
                        <DialogTitle className="text-white">Partner Application</DialogTitle>
                        <DialogDescription className="text-slate-400">
                          Apply to get matched with investors. No fees, no upfront costs.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 mt-4">
                        <Input placeholder="Your Name" className="bg-slate-800 border-slate-700" />
                        <Input placeholder="Email Address" className="bg-slate-800 border-slate-700" />
                        <Input placeholder="Business Idea/Experience" className="bg-slate-800 border-slate-700" />
                        <Button className="w-full bg-green-600 hover:bg-green-700">
                          Submit Application
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-white">Revenue-Based Financing</h4>
                  <p className="text-slate-400 text-sm">
                    Get $1,000-$50,000 upfront funding. Repay with a small percentage 
                    of your future revenue. No equity lost.
                  </p>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Apply for Funding
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Free Tools Section */}
      <section id="tools" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              100% Free Tools & Resources
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Everything you need to start earning - no credit card required, ever
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Free Hosting */}
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Globe className="w-5 h-5 text-blue-400" />
                  Free Web Hosting
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: 'JordanHost', features: '2GB NVMe, cPanel, No Ads' },
                  { name: 'InfinityFree', features: '5GB, Unlimited Bandwidth' },
                  { name: 'UltimateFreeHost', features: 'cPanel, SSL, No Ads' },
                  { name: 'FreeHostingNoAds', features: '1GB, Website Builder' }
                ].map((host, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                    <div>
                      <p className="text-white font-medium">{host.name}</p>
                      <p className="text-slate-400 text-sm">{host.features}</p>
                    </div>
                    <CopyButton text={host.name} label="Copy" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Affiliate Networks */}
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-green-400" />
                  Affiliate Networks
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: 'ClickBank', features: 'High commissions, Instant approval' },
                  { name: 'ShareASale', features: 'Thousands of merchants' },
                  { name: 'Impact', features: 'Top brands, Real-time tracking' },
                  { name: 'CJ Affiliate', features: 'Global network, Deep linking' }
                ].map((network, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                    <div>
                      <p className="text-white font-medium">{network.name}</p>
                      <p className="text-slate-400 text-sm">{network.features}</p>
                    </div>
                    <CopyButton text={network.name} label="Copy" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Design Tools */}
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Star className="w-5 h-5 text-purple-400" />
                  Design & Content
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: 'Canva', features: 'Free design templates' },
                  { name: 'CapCut', features: 'Video editing' },
                  { name: 'Grammarly', features: 'Writing assistant' },
                  { name: 'Remove.bg', features: 'Background removal' }
                ].map((tool, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                    <div>
                      <p className="text-white font-medium">{tool.name}</p>
                      <p className="text-slate-400 text-sm">{tool.features}</p>
                    </div>
                    <CopyButton text={tool.name} label="Copy" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Marketing Tools */}
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-yellow-400" />
                  Marketing Tools
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: 'Buffer', features: 'Social media scheduling' },
                  { name: 'Mailchimp', features: 'Email marketing (free tier)' },
                  { name: 'Google Analytics', features: 'Website analytics' },
                  { name: 'Ubersuggest', features: 'Keyword research' }
                ].map((tool, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                    <div>
                      <p className="text-white font-medium">{tool.name}</p>
                      <p className="text-slate-400 text-sm">{tool.features}</p>
                    </div>
                    <CopyButton text={tool.name} label="Copy" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* E-commerce Platforms */}
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-red-400" />
                  E-commerce Platforms
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: 'Printify', features: 'Print-on-demand, $0 upfront' },
                  { name: 'Etsy', features: 'Handmade & digital products' },
                  { name: 'Gumroad', features: 'Digital products, instant payouts' },
                  { name: 'Shopify', features: '14-day free trial' }
                ].map((platform, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                    <div>
                      <p className="text-white font-medium">{platform.name}</p>
                      <p className="text-slate-400 text-sm">{platform.features}</p>
                    </div>
                    <CopyButton text={platform.name} label="Copy" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Traffic Sources */}
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-indigo-400" />
                  Free Traffic Sources
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: 'TikTok', features: 'Viral potential, no followers needed' },
                  { name: 'YouTube', features: 'SEO traffic, long-term views' },
                  { name: 'Pinterest', features: 'Visual search engine' },
                  { name: 'Reddit', features: 'Niche communities' }
                ].map((source, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                    <div>
                      <p className="text-white font-medium">{source.name}</p>
                      <p className="text-slate-400 text-sm">{source.features}</p>
                    </div>
                    <CopyButton text={source.name} label="Copy" />
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Calculator Section */}
      <section id="calculator" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Income Potential Calculator
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              See exactly how much you could be earning with different income streams
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Calculator Inputs */}
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Calculate Your Potential</CardTitle>
                <CardDescription className="text-slate-400">
                  Adjust the sliders to see your earning potential
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-slate-300">Daily Website Visitors</label>
                    <Input 
                      type="number" 
                      placeholder="1000" 
                      className="bg-slate-800 border-slate-700 mt-2"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-slate-300">Conversion Rate (%)</label>
                    <Input 
                      type="number" 
                      placeholder="3" 
                      className="bg-slate-800 border-slate-700 mt-2"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-slate-300">Average Commission ($)</label>
                    <Input 
                      type="number" 
                      placeholder="50" 
                      className="bg-slate-800 border-slate-700 mt-2"
                    />
                  </div>
                </div>

                <Button className="w-full bg-gradient-to-r from-green-600 to-blue-600">
                  Calculate Earnings
                  <BarChart3 className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            {/* Results */}
            <Card className="bg-gradient-to-br from-green-900/50 to-blue-900/50 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Wallet className="w-5 h-5 text-green-400" />
                  Your Earning Potential
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-slate-800/50 rounded-lg">
                    <p className="text-3xl font-bold text-green-400">$75</p>
                    <p className="text-slate-400 text-sm">Daily Earnings</p>
                  </div>
                  <div className="text-center p-4 bg-slate-800/50 rounded-lg">
                    <p className="text-3xl font-bold text-blue-400">$2,250</p>
                    <p className="text-slate-400 text-sm">Monthly Earnings</p>
                  </div>
                  <div className="text-center p-4 bg-slate-800/50 rounded-lg">
                    <p className="text-3xl font-bold text-purple-400">$27,000</p>
                    <p className="text-slate-400 text-sm">Yearly Earnings</p>
                  </div>
                  <div className="text-center p-4 bg-slate-800/50 rounded-lg">
                    <p className="text-3xl font-bold text-yellow-400">$0</p>
                    <p className="text-slate-400 text-sm">Startup Cost</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-300">Progress to First $1,000</span>
                    <span className="text-green-400">75%</span>
                  </div>
                  <Progress value={75} className="bg-slate-700" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Comparison Table */}
          <Card className="mt-8 bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">Income Stream Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-700">
                      <th className="py-3 px-4 text-slate-300">Method</th>
                      <th className="py-3 px-4 text-slate-300">Difficulty</th>
                      <th className="py-3 px-4 text-slate-300">Startup Cost</th>
                      <th className="py-3 px-4 text-slate-300">Potential/Month</th>
                      <th className="py-3 px-4 text-slate-300">Time to Profit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { method: 'Affiliate Marketing', difficulty: 'Easy', cost: '$0', potential: '$500-$10,000', time: '1-3 months' },
                      { method: 'Print-on-Demand', difficulty: 'Easy', cost: '$0', potential: '$100-$5,000', time: '1-2 months' },
                      { method: 'CPA Marketing', difficulty: 'Medium', cost: '$0', potential: '$200-$8,000', time: '2-4 weeks' },
                      { method: 'Dropshipping', difficulty: 'Medium', cost: '$0', potential: '$500-$20,000', time: '1-3 months' },
                      { method: 'Content Creation', difficulty: 'Hard', cost: '$0', potential: '$100-$50,000', time: '3-6 months' }
                    ].map((row, i) => (
                      <tr key={i} className="border-b border-slate-800 hover:bg-slate-800/30">
                        <td className="py-3 px-4 text-white font-medium">{row.method}</td>
                        <td className="py-3 px-4">
                          <Badge 
                            variant={row.difficulty === 'Easy' ? 'default' : 'secondary'}
                            className={row.difficulty === 'Easy' ? 'bg-green-600' : row.difficulty === 'Medium' ? 'bg-yellow-600' : 'bg-red-600'}
                          >
                            {row.difficulty}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-green-400 font-medium">{row.cost}</td>
                        <td className="py-3 px-4 text-blue-400 font-medium">{row.potential}</td>
                        <td className="py-3 px-4 text-slate-300">{row.time}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-green-900/50 to-blue-900/50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6">
            Ready to Start Your Passive Income Journey?
          </h2>
          <p className="text-slate-300 text-lg mb-8 max-w-2xl mx-auto">
            Join thousands who are already building wealth with these proven methods. 
            No experience needed, no money required - just follow the steps.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-slate-900 hover:bg-slate-200 px-8"
              onClick={() => scrollToSection('methods')}
            >
              Get Started Now
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-slate-600 hover:bg-slate-800"
              onClick={() => scrollToSection('tools')}
            >
              View All Free Tools
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-blue-500 rounded-lg flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
                Wealth Engine
              </span>
            </div>
            <p className="text-slate-400 text-sm">
              © 2025 Wealth Engine. Build passive income with zero investment.
            </p>
            <div className="flex items-center gap-4">
              <span className="text-slate-400 text-sm">Earnings Disclaimer:</span>
              <span className="text-slate-500 text-xs max-w-xs">
                Results vary based on effort and market conditions. No income guarantees.
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
